define({
  "_widgetLabel": "Zaglavlje",
  "signin": "Prijavite se",
  "signout": "Odjava",
  "about": "Informacije",
  "signInTo": "Prijavi se u",
  "cantSignOutTip": "Funkcija nije dostupna u načinu pretpregleda."
});