define({
  "_widgetLabel": "Contrôleur de la barre d'ancrage",
  "_layout_default": "Mise en page par défaut",
  "_layout_layout1": "Mise en page 0",
  "more": "Plus de widgets"
});