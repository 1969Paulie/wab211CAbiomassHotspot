define({
  "_widgetLabel": "एंकर बार नियंत्रक",
  "_layout_default": "डिफ़ॉल्ट रूपरेखा",
  "_layout_layout1": "रूपरेखा 0",
  "more": "अधिक विजेट"
});