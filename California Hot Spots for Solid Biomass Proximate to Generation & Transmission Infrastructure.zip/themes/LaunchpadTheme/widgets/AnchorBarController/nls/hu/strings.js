define({
  "_widgetLabel": "Dokkolósáv vezérlő",
  "_layout_default": "Alapértelmezett elrendezés",
  "_layout_layout1": "0. elrendezés",
  "more": "További widgetek"
});