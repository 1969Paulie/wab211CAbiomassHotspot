define({
  "_widgetLabel": "בקר סרגל עוגנים",
  "_layout_default": "פריסת ברירת מחדל",
  "_layout_layout1": "פריסה 0",
  "more": "ווידג'טים נוספים"
});