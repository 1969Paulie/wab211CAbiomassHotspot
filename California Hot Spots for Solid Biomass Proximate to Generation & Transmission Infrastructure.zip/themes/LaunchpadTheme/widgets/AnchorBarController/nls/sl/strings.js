define({
  "_widgetLabel": "Kontrolnik vrstice sidra",
  "_layout_default": "Privzeta postavitev",
  "_layout_layout1": "Postavitev 0",
  "more": "Več pripomočkov"
});