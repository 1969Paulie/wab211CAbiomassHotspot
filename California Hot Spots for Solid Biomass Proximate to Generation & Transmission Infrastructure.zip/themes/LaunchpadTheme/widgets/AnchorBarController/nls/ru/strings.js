define({
  "_widgetLabel": "Контроллер панели якоря",
  "_layout_default": "Компоновка по умолчанию",
  "_layout_layout1": "Компоновка 0",
  "more": "Ещё виджеты"
});