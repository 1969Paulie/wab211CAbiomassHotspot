define({
  "_widgetLabel": "แถบควบคุมหลัก",
  "_layout_default": "เค้าโครงเริ่มต้น",
  "_layout_layout1": "โครงร่าง 0",
  "more": "วิดเจ็ตเพิ่มเติม"
});