define({
  "_themeLabel": "Fırlatma Rampası Teması",
  "_layout_default": "Varsayılan düzen",
  "_layout_right": "Doğru düzen"
});